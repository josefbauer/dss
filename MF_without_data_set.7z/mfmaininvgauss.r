####SETTINGS####

#set working directory (where files and data are stored)
setwd("C:/MF")

#data set to use
datasource <- "E-Commerce"

#grid search:
#matrix of parameter values to be iterated through (learning rate, regularization parameter, momentum, number of features, additional distributional parameter)
#(note that the learning rate specified here is divided by the batchsize internally)
#values for each parameter are separated by a comma
parametervaluematrix <- expand.grid(c(500), c(0.0375), c(0.4), c(50), c(22.5))

#number of epochs
maxepoch <- 300

#exclude count values larger than
truncatethresholdmax <- 100

#exclude count values smaller than
truncatethresholdmin <- 3

#exclude users and items with observations less or equal than
excludesparseuseritemsthreshold <- 5




####COMPUTATION####


library(compiler)

enableJIT(3)

library(inline)

#C++ helper function for gradient descent update calculation
cpp_grad_f_b <- "
  Rcpp::NumericVector v(a);
  Rcpp::NumericMatrix M(B);
  Rcpp::NumericMatrix N(C);
  int size_v = v.size();
  for (int i=0; i < size_v; i++){
		M(v[i]-1,_) = M(v[i]-1,_) + N(i,_);
  }
  return M;
"
cpp_grad_f <- cxxfunction(signature(a="numeric", B="numeric", C="numeric"), body = cpp_grad_f_b, plugin = "Rcpp")

biasaveragetype <- "median"

source(paste(getwd(),"/createuseritemdata.r",sep=""))

createuseritemdata(datasource)

source(paste(getwd(),"/processuseritemdata.r",sep=""))

processuseritemdata(sampledata,truncatethresholdmin,truncatethresholdmax,excludesparseuseritemsthreshold)

source(paste(getwd(),"/generatetrainingvalidationdata.r",sep=""))

generatetrainingvalidationdata(sampledata,datasource)



minvalidationmaderrorvalue <- 1000
minvalidationmaderrorvalueparamlog <- "not yet defined"


for (parindex in 1:length(parametervaluematrix[,1])){


#learning rate
epsilon <- parametervaluematrix[parindex,1]

#regularization parameter
lambda <- parametervaluematrix[parindex,2]

#momentum parameter
momentum <- parametervaluematrix[parindex,3]

numberoffeatures <- parametervaluematrix[parindex,4]

vartheta <- parametervaluematrix[parindex,5]

print("Additional distribution parameter:")
print(vartheta)


cat("\n\n")
print(sprintf("epsilon: %f  lambda: %f  momentum: %f  number of features: %i", epsilon, lambda, momentum, numberoffeatures))


itemfeaturematrix <- sqrt(1/numberoffeatures)*(1.5*matrix(rnorm(numberofitems*numberoffeatures, mean = 0, sd = 1), numberofitems, numberoffeatures))

userfeaturematrix <- sqrt(1/numberoffeatures)*(1.5*matrix(rnorm(numberofusers*numberoffeatures, mean = 0, sd = 1), numberofusers, numberoffeatures))


itembiasmatrix <- matrix(0, numberofitems, 1)

itembiasmatrix[itembiases[,1],] <- itembiases[,2]

userbiasmatrix <- matrix(0, numberofusers, 1)

userbiasmatrix[userbiases[,1],] <- userbiases[,2]

itemfeaturematrix_inc <- matrix(0, numberofitems, numberoffeatures)

userfeaturematrix_inc <- matrix(0, numberofusers, numberoffeatures)

itembiasmatrix_inc <- matrix(0, numberofitems, 1)

userbiasmatrix_inc <- matrix(0, numberofusers, 1)

validationerror <- rep(0, maxepoch)


for (epoch in 1:maxepoch){

randomtrainingdatapermutation <- sample(1:trainingsamplesize, size = trainingsamplesize, replace = FALSE)

trainingmatrix <- trainingmatrix[randomtrainingdatapermutation,]

for (batch in 1:numberofbatches){

#computation of the predictions on the training set

	userbatch <- trainingmatrix[((batch-1)*batchsize+1):(batch*batchsize),1]

	itembatch <- trainingmatrix[((batch-1)*batchsize+1):(batch*batchsize),2]
	
	ratingbatch <- trainingmatrix[((batch-1)*batchsize+1):(batch*batchsize),3]

	#(users and items are integers and can therefore be treated as indices)
	featdotprodbatch <- rowSums(itemfeaturematrix[itembatch,]*userfeaturematrix[userbatch,])

	#computation of gradients
	
	biasbatch <- predictionadjustment + userbiasmatrix[userbatch,] + itembiasmatrix[itembatch,]

	featplusbiasbatch <- featdotprodbatch + biasbatch
	
	D_useritemcoefficient <- vartheta*(ratingbatch/featplusbiasbatch^3 - 1/featplusbiasbatch^2)
	  
	M_base_feat <- kronecker(-D_useritemcoefficient, matrix(1,1,numberoffeatures))
	
	M_item <- M_base_feat*userfeaturematrix[userbatch,] + 2*lambda*itemfeaturematrix[itembatch,]
	
	M_user <- M_base_feat*itemfeaturematrix[itembatch,] + 2*lambda*userfeaturematrix[userbatch,]
  
	M_base_bias <- as.matrix(-D_useritemcoefficient)
	
	M_itembias <- M_base_bias + 2*lambda*itembiasmatrix[itembatch,]
	
	M_userbias <- M_base_bias + 2*lambda*userbiasmatrix[userbatch,]
	
	d_itemfeaturematrix <- matrix(0,numberofitems,numberoffeatures)
	
	d_userfeaturematrix <- matrix(0,numberofusers,numberoffeatures)
	
	d_itemfeaturematrix <- cpp_grad_f(itembatch,d_itemfeaturematrix,M_item)
	
	d_userfeaturematrix <- cpp_grad_f(userbatch,d_userfeaturematrix,M_user)

	d_itembiasmatrix <- matrix(0,numberofitems,1)
	
	d_userbiasmatrix <- matrix(0,numberofusers,1)
	
	d_itembiasmatrix <- cpp_grad_f(itembatch,d_itembiasmatrix,M_itembias)
	
	d_userbiasmatrix <- cpp_grad_f(userbatch,d_userbiasmatrix,M_userbias)
	

	#update of item features
	itemfeaturematrix_inc <- momentum*itemfeaturematrix_inc + epsilon*(d_itemfeaturematrix/batchsize)
	itemfeaturematrix <- itemfeaturematrix - itemfeaturematrix_inc
	
	#update of user features
	userfeaturematrix_inc <- momentum*userfeaturematrix_inc + epsilon*(d_userfeaturematrix/batchsize)
	userfeaturematrix <- userfeaturematrix - userfeaturematrix_inc
	
	#update of item biases
	itembiasmatrix_inc <- momentum*itembiasmatrix_inc + epsilon*(d_itembiasmatrix/batchsize)
	itembiasmatrix <- itembiasmatrix - itembiasmatrix_inc
	
	#update of user biases
	userbiasmatrix_inc <- momentum*userbiasmatrix_inc + epsilon*(d_userbiasmatrix/batchsize)
	userbiasmatrix <- userbiasmatrix - userbiasmatrix_inc
	
}

	#computation of the predictions after parameter updates
    
	biasbatch <- predictionadjustment + userbiasmatrix[userbatch,] + itembiasmatrix[itembatch,]
  
	featdotprodbatch <- rowSums(itemfeaturematrix[itembatch,]*userfeaturematrix[userbatch,])
  
	predictionbatch <- featdotprodbatch + biasbatch


#computation of the predictions on the validation set

	uservalidationbatch <- validationmatrix[,1]
	
	itemvalidationbatch <-  validationmatrix[,2]
	
	ratingvalidationbatch <- validationmatrix[,3]
	
 
	biasvalidationbatch <- predictionadjustment + userbiasmatrix[uservalidationbatch,] + itembiasmatrix[itemvalidationbatch,]
  
	featdotprodvalidationbatch <- rowSums(itemfeaturematrix[itemvalidationbatch,]*userfeaturematrix[uservalidationbatch,])
  
  	predictionvalidationbatch <- featdotprodvalidationbatch + biasvalidationbatch

	
	#mean absolute error on the validation set
	validationerror[epoch] <- sum(abs(predictionvalidationbatch - ratingvalidationbatch))/validationsamplesize

	#handling of divergence for inappropriate parameter settings
	if (is.na(validationerror[epoch]) | is.nan(validationerror[epoch]) | !(is.finite(validationerror[epoch]))){

	validationerror[epoch:maxepoch] <- NaN

	break

	}

	if (validationerror[epoch] < minvalidationmaderrorvalue){
	minvalidationmaderrorvalue <- validationerror[epoch]
	minvalidationmaderrorvalueparamlog <- paste("At epoch ",toString(epoch)," for parameter settings "," epsilon = ",toString(epsilon),", lambda = ",toString(lambda),", momentum = ",toString(momentum),", nfeatures = ",toString(numberoffeatures),
		" distparam = ",toString(vartheta)," maxepoch = ",toString(maxepoch)," ",toString(datasource)," truncmax = ",toString(truncatethresholdmax)," truncmin = ",toString(truncatethresholdmin)," excl = ",toString(excludesparseuseritemsthreshold))
	}

	
#error output
print(sprintf("Epoch %i:  Validation Mean Absolute Error: %6.4f", epoch, validationerror[epoch]))


}


print("Minimum Validation Mean Absolute Error achieved:")
print(round(minvalidationmaderrorvalue,4))
print(minvalidationmaderrorvalueparamlog)


}


