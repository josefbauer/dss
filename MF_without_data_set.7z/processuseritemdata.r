processuseritemdata <- function (sampledata,truncatethresholdmin,truncatethresholdmax,excludesparseuseritemsthreshold) {
#returns filtered data in the form (user_id,item_id,rating), all being integer

#truncate too small and too large values/outliers
sampledata <- sampledata[(sampledata[,3] <= truncatethresholdmax)&(sampledata[,3] >= truncatethresholdmin),]

#exclude users and items with a low number of observed (user,item,rating/count)-triplets
usercounttable <- table(sampledata[,1])
userstoexcludechar <- names(usercounttable[usercounttable <= excludesparseuseritemsthreshold])
itemcounttable <- table(sampledata[,2])
itemstoexcludechar <- names(itemcounttable[itemcounttable <= excludesparseuseritemsthreshold])
sampledata <- sampledata[!is.element(as.character(sampledata[,1]),userstoexcludechar)&!is.element(as.character(sampledata[,2]),itemstoexcludechar),]

#conversion of unique ints of users and items to 1:max (so that they can be treated as indices of the user and item feature matrices)
sampledata[,1] <- as.integer(as.factor(sampledata[,1]))
sampledata[,2] <- as.integer(as.factor(sampledata[,2]))

sampledata <<- sampledata

}

